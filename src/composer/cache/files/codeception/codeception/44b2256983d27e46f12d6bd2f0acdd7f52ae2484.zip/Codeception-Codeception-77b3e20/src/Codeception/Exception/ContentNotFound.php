<?php
namespace Codeception\Exception;

class ContentNotFound extends \PHPUnit\Framework\AssertionFailedError
{
}
